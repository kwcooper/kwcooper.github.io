Contact
=======

> email: <cafefantasia@cust.in>
>
> Hirschstr. 2a
> 76133 Karlsruhe / Germany
> Phone: +49(0)721-555-123567

[gimmick:GoogleMaps (zoom: 13)](Hirschstr. 2a, 76133 Karlsruhe)

Opening Hours
-------------

Mo-Fr: 8AM-11PM
Sa-Su: 9AM-11PM
