Lunch specials
==============

Our updated lunch special for this week:

Entries and Salads
------------------

* Garlic-boiled white mushrooms served in herb butter					*4,90 €*
* Chefsalad with Bacon													*6,20 €*
* Green salad (optional with onions)
 * small 				*3,20 €*
 * large				*4,90 €*

- - -

Main dishes
-----------

* Coalfish "Müllerin Art"												*7,80 €*
* Tortelini à la Panna, in cream sauce 									*6,90 €*

- - -

Dessert
-------

* Icecream, mixed flavours												*3,20 €*
* Cheeseplate 															*4,30 €*
  * with fresh fruits													*6,50 €*


