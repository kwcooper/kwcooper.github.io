---
layout: page
title: About
permalink: /about/
---



### More Information

Soon...

### Contact me

[kc42@iu.edu](mailto:kc42@iu.edu)