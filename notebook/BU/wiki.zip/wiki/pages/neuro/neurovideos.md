Neuro videos playlist
=======

I’ve collected a fair amount of online lectures and seminars on neuroscience related topics with wonderful speakers. Feel free to give this playlist a watch or scan through them for a topic of interest. 

<iframe width="720" height="405" src="https://www.youtube.com/embed/?listType=playlist&list=PLXoR_9BNEkVCm1oe-h2Ie6OaPRzuVc8Q2" frameborder="0" allowfullscreen>


init 190219


