Open Neuroscience datasets
=======

for play :)
---------

[...]

fMRI 
---------

|||
|-|-|
| [OpenNeuro](https://openneuro.org/) |  Nice database of open fMRI Data |
| [NeuroVault](http://neurovault.org/) | statistical maps from fMRI Data |
| [Human Connectome Project](http://www.humanconnectomeproject.org/) | Brain Nets  |



[...]



[Open Brain science index](http://www.mrc-cbu.cam.ac.uk/openscience/resources/)



init 190410
ud   190410
