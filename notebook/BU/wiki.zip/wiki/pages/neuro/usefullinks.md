Other useful links
=======

...
---------

[NIF](https://neuinfo.org/) - A _huge_ database search engine of... well... everything neuro

[CompNeuro Index](http://home.earthlink.net/~perlewitz/) - site similar to this but for resources for comp neuro (maintained by Jim Perlewitz)



(soon to be moved...)
---------

Summer courses 
|||
|-|-|
| [RIKEN CBS Summer Program](https://cbs.riken.jp/en/summer/) | Lecture course |
| [uOttawa](http://www.neurodynamic.uottawa.ca/summer.html) | Neural data analysis and modeling course |


TUT: [Finding good reviews](https://brodylabwiki.princeton.edu/wiki/index.php?title=Finding_Review_Papers)


init 190410
ud   190410