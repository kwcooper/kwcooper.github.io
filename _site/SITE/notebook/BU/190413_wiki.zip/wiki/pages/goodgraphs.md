Graphs that changed how I think
=======

How people spend their time
---------

[...]

Things are getting better
---------

[...]


The steam engine changed more than anything else
---------
[...]



init 190219
ud   190219

