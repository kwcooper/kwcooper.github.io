Python
=======

cool commands
---------

The best command known to man
Will run the file in terminal similar to IDLE
TODO: port this directly to sublime in some crazy way...
`exec(open("filename.py").read())`


To find python path information
`for p in sys.path:
    print(p)`

To find information on a packages path
`import os
import a_module
print(a_module.__file__)
path = os.path.dirname(a_module.__file__)




tricks
---------
Store passwords with keyring
[alex chan's blog post on it](https://alexwlchan.net/2016/11/you-should-use-keyring/)


useful links
---------

[Guide](https://the-hitchhikers-guide-to-packaging.readthedocs.io/en/latest/creation.html) to creating a python package from PyPi

[...]

init 190122
ud   190219