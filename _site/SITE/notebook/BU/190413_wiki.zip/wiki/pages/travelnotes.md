Travel notes
=======

Pointers
---------

* Ask the hotel front desk what is and isn't complementary 

Links
---------

[...]


init 190219
ud   190219
