Funding
=======

List of grants
---------

Science is hard. Securing the money to do science is harder. 


List -o- grants

|||
|-|-|
| [GRFP]() | NSF UG/Grad student $ |
| [Burrough's](http://www.bwfund.org/programs/interfaces/career_awards_background.html) | ... |
| [NRSA (F32)](http://grants1.nih.gov/grants/guide/pa-files/PA-07-107.html) | NIH $ |
| [MQRDA (K25)](http://grants.nih.gov/grants/guide/pa-files/PA-06-087.html) | NIH $ |


[Computational Neuroscience funding index](http://home.earthlink.net/~perlewitz/funding.html) 


Grant Writing advice
---------

[NIH tips and sheets](https://grants.nih.gov/grants/grant_tips.htm)


init 190410
ud   190410