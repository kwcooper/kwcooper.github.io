Keiland's open source notebook
=======

  My notes are scattered across notebooks, post-its, note keeping apps, documents, envelopes, etc. This site comprises my effort to consolidate them in an easy to find place, which others may find useful. 


[//]: # (for images: ![](http://placekitten.com/g/250/250))



