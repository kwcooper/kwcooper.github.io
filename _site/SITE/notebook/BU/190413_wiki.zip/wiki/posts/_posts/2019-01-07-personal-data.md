---
layout: post
title: Personal Data
---

I’m still figuring out where I land on the open personal data online debate. It’s probably not completely safe yet, but also probably not as bad as everyone thinks. In any case, I thought it best to purge some of my closely identifiable information from various repo’s. This is a running list of those sites. It may be a good yearly habit to run through the sites and check what info is published. 


Most sites have a link that makes it easy to remove your data. Alternatively, googling ‘_site name_ opt out’ tends to yield good results to save time searching yourself. 


These were recommended from brand yourself:

* WhitePages
* Intelius
* InstantCheckmate
* TruthFinder
* Acxiom

Acxiom’s opt out form was a bit harder to [find](https://isapps.acxiom.com/optout/optout.aspx) 

So far, I opted out of Intel, Instant checkmate, and Acxiom, will have to wait a few weeks to assess the results. My info wasn’t on TruthFinder. I kept it on white pages just in case someone needs to look me up the old fashion way to get into contact. Though with all of the digital resources available, this may change in a year or so. 

From a lifework [article](https://www.lifewire.com/remove-personal-information-from-internet-3482691) I pulled a few more. 

* Radaris
* USA People Search
* PrivateEye.com & PublicRecordsNOW
* ZabaSearch
* PeekYou
* BeenVerified
* AnyWho

Zabasearch was annoying, and required a fax of your ID, my info wasn’t on any of the other sites. 


_Last updated 190107_







