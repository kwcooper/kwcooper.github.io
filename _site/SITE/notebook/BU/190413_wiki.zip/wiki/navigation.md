# Notebook

[Tech]()
 
  * # lists
  * [software I like](pages/tech/software.md)
  * [good places](pages/tech/softwarePlaces.md)
  - - - -
  * # programming notes
  * [python](pages/tech/python.md)
  * [matlab](pages/tech/matlab.md)
  * [git](pages/tech/git.md)
  * [R](pages/tech/r.md)
  - - - -
  * # networking
  * [apache](pages/tech/apache.md)
  * [ssh](pages/tech/ssh.md)
  - - - - 
  * # other
  * [bash](pages/tech/bash.md)
  * [ocamlfuse](pages/tech/ocamlfuse.md)
  - - - -
  * [snips](https://gist.github.com/kwcooper)

[Neuro]()
  
  * # lists
  * [videos](pages/neuro/neurovideos.md)
  * [open datasets](pages/neuro/neurodata.md)
  - - - -
  * # other
  * [Useful links](pages/neuro/usefullinks.md)


[Academia]()

  * # lists
  * [funding](pages/academ/funds.md)
  - - - -
  * # other

  
[other]()
  
  * # lists
  * [travel notes](pages/travelnotes.md)
  * [airplanes]()
  - - - -
  * # Finance
  _ _ _ _
  * # Quantified Self
  * 

[other](directlink.md)
